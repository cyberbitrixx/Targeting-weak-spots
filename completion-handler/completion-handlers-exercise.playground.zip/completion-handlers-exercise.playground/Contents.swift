import UIKit


// COMPLETION-HANDLERS EXPLAINED

// MARK: - The issue Completion Handlers solve

// In real API calls completion handler is being used to solve the synchronous code issue (like the function below), to be able to not execute the rest of the code until a certain task was completed (API call was made and response was recieved)

func trialFunc() {
    DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + 2) {
        print("First statement")
    }
    print("Second statement")
}

trialFunc()

// MARK: - OUTPUT: "Second statement" is being printed first, and after 2 seconds "First statement" is being printed


// MARK: - Function with () -> Void Completion Block

// 1. A completion block is simply a block of code that will be executed when the main task was completed.
// 2. Completion-handler is being defined as any other argument in the function:
//      - parameter name;
//      - a type, which is a closure.

// In that case the closure takes no parameters and returns nothing, which makes the closure () -> Void (another option is () -> ())
func sampleFunc(completion: @escaping () -> Void) {
    DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + 2) {
        print("Response from delayed sample function")
        completion()
    }
}


// MARK: - @escaping

// 1. Completion handlers are closures, which means they are escaping by default
// 2. Escaping closure is a closure, which is being called after the function it was passed to - returns (outlives the function it was passed to)

// MARK: - That's where keyword @escaping should be added to not get an error "Escaping closure captures non-escaping parameter 'completion'"

// in this case completion parameter represents our function's body, so it can be simply replaced with {}
sampleFunc(completion: {
    print("After the response from the delayed sample function")
})

// MARK: - The option above is a not the best way to do it. To do it more Swift-way, use trailing closure instead


// MARK: TRAILING CLOSURES

//  A trailing closure is when the closure is a last parameter (or argument) in the function. That's when you can eliminate the argument's label, and only code block will be remaining

sampleFunc {
    print("After the response from the delayed sample function")
}


// MARK: - Function with (T) -> Void Completion Block

// When your closure includes a parameter
func funcWithTrailingAndParameter(completion: @escaping (String) -> Void) {
    DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + 2) {
        print("Response from delayed sample function")
        completion("After the response from delayed sample function")
    }
}

// Because closures don't have function names and argument labels, we name the arguments inside the brackets when calling the function with this closure (here "response") so we can print out our "response" the completion block
// Call the function
funcWithTrailingAndParameter { (response) in
    print(response)
}

// MARK: - OUTPUT: "Response from delayed sample function" is being printed first after the code executed waits 2 seconds, and then "Ater the response from delayed sample function" is being printed immidiately



// MARK: - Function with parameter AND (T) -> Void Completion Block

// When the function includes a parameter, and the closure includes one too
func funcParameterAndClosureParameter(searchString: String, completion: @escaping (String) -> Void) {
    print("You're about to search for \(searchString)")
    DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + 2) {
//        Run the completion block
        completion("\(searchString): Best programming language.")
    }
}

// Now when we call the function we have to provide a searchString, and (double-clicking on the completion code) we get to name the completion argument, which will be used in the code block
funcParameterAndClosureParameter(searchString: "Swift") { response in
    print(response)
}

// MARK: - OUTPUT: The first argument is being passed to the function (searchString), which is then used by the completion block, to manipulate the searchString, that is passed back to the argument
